'use strict';

angular.module('app', ['7minWorkout']);

angular.module('7minWorkout', []);
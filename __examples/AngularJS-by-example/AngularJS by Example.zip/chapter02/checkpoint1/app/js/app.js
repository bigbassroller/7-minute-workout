'use strict';

angular.module('app', []);

angular.module('7minWorkout', []);
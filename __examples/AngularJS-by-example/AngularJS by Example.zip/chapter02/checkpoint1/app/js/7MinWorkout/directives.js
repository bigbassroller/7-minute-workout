﻿'use strict';

/* Directives */
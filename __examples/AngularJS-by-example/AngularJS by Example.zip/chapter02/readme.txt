1. Each of the checkpoint folders contain the state of the app that was incrementally build in chapter 2.
2. This helps the user to start building the app from scratch or  from any checkpoint and continue building over it as the chapter progresses.
3. There are total 7 checkpoints in the app. Each of them have been marked in the chapter text.
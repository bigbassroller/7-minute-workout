'use strict';

angular.module('app', ['ngRoute', 'ngSanitize', '7minWorkout', 'WorkoutBuilder', 'mediaPlayer', 'ui.bootstrap', 'LocalStorageModule', 'ngAnimate', 'ngMessages', 'ngResource']);

angular.module('7minWorkout', []);
angular.module('WorkoutBuilder', []);